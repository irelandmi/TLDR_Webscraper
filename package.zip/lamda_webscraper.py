import json
import os
import boto3
from datetime import datetime, timedelta

def lambda_handler(event, context):
    """
    Event format:
    {
        "start_date": "2025-01-01",
        "end_date": "2025-01-31"
    }
    OR
    {
        "date": "2025-01-01"
    }
    """
    print("lamda started")
    s3 = boto3.client('s3')
    bucket = os.environ['S3_BUCKET']
    
    if 'date' in event:
        # Single date
        dates = [event['date']]
    else:
        # Date range
        dates = generate_date_range(
            event['start_date'],
            event['end_date']
        )
    
    results = []
    for date_str in dates:
        print(f"Scraping {date_str}")
        data = scrape_for_date(date_str)
        
        # Save to S3
        key = f"scraped_data/{date_str}.json"
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(data),
            ContentType='application/json'
        )
        
        results.append({
            'date': date_str,
            's3_key': key,
            'records': len(data)
        })
    
    return {
        'statusCode': 200,
        'body': json.dumps(results)
    }

def generate_date_range(start, end):
    start_dt = datetime.strptime(start, '%Y-%m-%d')
    end_dt = datetime.strptime(end, '%Y-%m-%d')
    
    dates = []
    current = start_dt
    while current <= end_dt:
        dates.append(current.strftime('%Y-%m-%d'))
        current += timedelta(days=1)
    
    return dates

def scrape_for_date(date_str):
    # Your scraping logic here
    return [{"example": "data", "date": date_str}]